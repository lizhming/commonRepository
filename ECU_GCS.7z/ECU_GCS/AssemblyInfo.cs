﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ECU_GCS_F")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ECU_GCS_F")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("5457da9a-ea95-4604-8ab6-bb417ddc69d4")]
[assembly: AssemblyFileVersion("1.0.2.2")]
[assembly: AssemblyVersion("1.0.2.2")]
