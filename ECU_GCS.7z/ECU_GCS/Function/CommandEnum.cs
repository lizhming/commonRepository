﻿// Decompiled with JetBrains decompiler
// Type: ECU_GCS.CommandEnum
// Assembly: ECU_GCS, Version=1.0.2.2, Culture=neutral, PublicKeyToken=null
// MVID: 4AB9C9F1-17D5-4990-AB25-69949DD24666
// Assembly location: D:\Business\OneDrive\Spatial_Collect\2.Agencies\1.Innoflight\10.Software\EFI SW V1.0\ECU_GCS.exe

namespace ECU_GCS
{
  internal enum CommandEnum
  {
    cmd_type_none,
    cmd_cdi1,
    cmd_cdi2,
    cmd_pump,
    cmd_flameout,
    cmd_pre_inj,
    cmd_thr,
    cmd_start,
    cmd_hot,
    cmd_jet_test,
  }
}
