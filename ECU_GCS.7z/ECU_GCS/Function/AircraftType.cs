﻿// Decompiled with JetBrains decompiler
// Type: ECU_GCS.AircraftType
// Assembly: ECU_GCS, Version=1.0.2.2, Culture=neutral, PublicKeyToken=null
// MVID: 4AB9C9F1-17D5-4990-AB25-69949DD24666
// Assembly location: D:\Business\OneDrive\Spatial_Collect\2.Agencies\1.Innoflight\10.Software\EFI SW V1.0\ECU_GCS.exe

namespace ECU_GCS
{
  public enum AircraftType
  {
    Q80 = 16, // 0x00000010
    F80 = 17, // 0x00000011
    D5 = 32, // 0x00000020
    D30 = 33, // 0x00000021
    X5 = 48, // 0x00000030
    X10 = 49, // 0x00000031
    X128 = 50, // 0x00000032
    V2500 = 64, // 0x00000040
    ECU = 80, // 0x00000050
  }
}
