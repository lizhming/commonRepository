﻿// Decompiled with JetBrains decompiler
// Type: ECU_GCS.CfgManager
// Assembly: ECU_GCS, Version=1.0.2.2, Culture=neutral, PublicKeyToken=null
// MVID: 4AB9C9F1-17D5-4990-AB25-69949DD24666
// Assembly location: D:\Business\OneDrive\Spatial_Collect\2.Agencies\1.Innoflight\10.Software\EFI SW V1.0\ECU_GCS.exe

using System;
using System.Drawing;
using System.Windows.Forms;

namespace ECU_GCS
{
  public class CfgManager
  {
    private int config_count = 102;
    private Timer timer1 = new Timer();
    private Timer timer2 = new Timer();

    public CfgManager()
    {
      this.timer1.Interval = 10;
      this.timer1.Tick += new EventHandler(this.Timer_Tick_Send);
      this.timer1.Start();
      for (int index = 0; index < Common.cfg_value.Length; ++index)
      {
        Common.cfg_value[index] = new CfgValue(0.0f, false);
        Common.cfg_value[index].Index = 0;
        Common.cfg_value[index].ReadValueFinish(0.0f);
        Common.cfg_value[index].num = 1000;
      }
      this.timer2.Interval = 10;
      this.timer2.Tick += new EventHandler(this.Timer_Tick_Rec);
      this.timer2.Start();
    }

    private void Timer_Tick_Send(object sender, EventArgs e)
    {
      for (int index1 = 0; index1 < 102; ++index1)
      {
        for (int index2 = 0; index2 <= 102; ++index2)
        {
          if (index1 == Common.cfg_value[index2].num && Common.cfg_value[index2].Name_Save != null && Common.cfg_value[index2].Index != 0)
          {
            if (Common.cfg_value[index2].NeedWrite)
            {
              if (DateTime.Now.Subtract(Common.SerialManager.sendDateTime).TotalMilliseconds <= 100.0)
                return;
              this.SendConfigContent((byte) Common.cfg_value[index2].Index, Common.cfg_value[index2].Value);
              return;
            }
            if (Common.cfg_value[index2].NeedRead)
            {
              if (DateTime.Now.Subtract(Common.SerialManager.sendDateTime).TotalMilliseconds <= 100.0)
                return;
              this.SendConfigRequest((byte) Common.cfg_value[index2].Index);
              return;
            }
          }
        }
      }
    }

    private void Timer_Tick_Rec(object sender, EventArgs e)
    {
      if (DateTime.Now.Subtract(C8_Content_Config.RecTime).TotalMilliseconds >= 300.0)
        return;
      Common.cfg_value[(int) C8_Content_Config.Data.index].ReadValueFinish(C8_Content_Config.Data.content);
      if (C8_Content_Config.Data.index < (byte) 12 && C8_Content_Config.Data.index >= (byte) 1)
        Common.ConfigTool.ThrOilPanelLoadData(Color.Blue);
      else if (C8_Content_Config.Data.index < (byte) 23 && C8_Content_Config.Data.index >= (byte) 12)
        Common.ConfigTool.ThrOil2PanelLoadData(Color.Blue);
      else if (C8_Content_Config.Data.index <= (byte) 33 && C8_Content_Config.Data.index >= (byte) 23)
        Common.ConfigTool.ThrExpPanelLoadData(Color.Blue);
      else if (C8_Content_Config.Data.index <= (byte) 44 && C8_Content_Config.Data.index >= (byte) 34)
        Common.ConfigTool.OilPrePanelLoadData(Color.Blue);
      else if (C8_Content_Config.Data.index <= (byte) 49 && C8_Content_Config.Data.index >= (byte) 45)
        Common.Cfg_BaseTool.FindJetName();
      if (Common.cfg_value[(int) C8_Content_Config.Data.index].NeedWrite && Common.cfg_value[(int) C8_Content_Config.Data.index].Value.Equals(C8_Content_Config.Data.content))
        Common.cfg_value[(int) C8_Content_Config.Data.index].WriteValueFinish();
    }

    private void SendConfigRequest(byte index)
    {
      byte[] bytes = Agreement_Helper.StructToBytes((object) new T7_Request_Config()
      {
        header0 = (byte) 181,
        header1 = (byte) 98,
        source = (byte) 195,
        target = (byte) 161,
        type = C7_Request_Config.Type,
        num = (byte) C7_Request_Config.Length,
        id = Common.Agreement.SendId,
        ack = (byte) 80,
        index = index,
        chk0 = (byte) 0,
        chk1 = (byte) 0,
        end0 = (byte) 13,
        end1 = (byte) 10
      });
      for (int index1 = 0; index1 < bytes.Length - 4; ++index1)
      {
        bytes[bytes.Length - 4] ^= bytes[index1];
        bytes[bytes.Length - 3] ^= bytes[bytes.Length - 4];
      }
      Common.SerialManager.SendData(bytes);
    }

    private void SendConfigContent(byte ind, float value)
    {
      byte[] bytes = Agreement_Helper.StructToBytes((object) new T8_Content_Config()
      {
        header0 = (byte) 181,
        header1 = (byte) 98,
        source = (byte) 195,
        target = (byte) 161,
        type = C8_Content_Config.Type,
        num = (byte) C8_Content_Config.Length,
        id = Common.Agreement.SendId,
        ack = (byte) 0,
        index = ind,
        content = value,
        chk0 = (byte) 0,
        chk1 = (byte) 0,
        end0 = (byte) 13,
        end1 = (byte) 10
      });
      for (int index = 0; index < bytes.Length - 4; ++index)
      {
        bytes[bytes.Length - 4] ^= bytes[index];
        bytes[bytes.Length - 3] ^= bytes[bytes.Length - 4];
      }
      Common.SerialManager.SendData(bytes);
    }
  }
}
