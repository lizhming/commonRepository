﻿// Decompiled with JetBrains decompiler
// Type: ECU_GCS.sys_data_c
// Assembly: ECU_GCS, Version=1.0.2.2, Culture=neutral, PublicKeyToken=null
// MVID: 4AB9C9F1-17D5-4990-AB25-69949DD24666
// Assembly location: D:\Business\OneDrive\Spatial_Collect\2.Agencies\1.Innoflight\10.Software\EFI SW V1.0\ECU_GCS.exe

namespace ECU_GCS
{
  public static class sys_data_c
  {
    public static int thr_value;
  }
}
