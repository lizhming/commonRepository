﻿// Decompiled with JetBrains decompiler
// Type: ECU_GCS.DataReplayWindow
// Assembly: ECU_GCS, Version=1.0.2.2, Culture=neutral, PublicKeyToken=null
// MVID: 4AB9C9F1-17D5-4990-AB25-69949DD24666
// Assembly location: D:\Business\OneDrive\Spatial_Collect\2.Agencies\1.Innoflight\10.Software\EFI SW V1.0\ECU_GCS.exe

using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ECU_GCS
{
  public class DataReplayWindow : Form
  {
    private FileReadClass FileRead = new FileReadClass();
    private Timer timer = new Timer();
    private Timer timer_play = new Timer();
    private DateTime play_tic = DateTime.Now;
    private uint file_open_flag = 0;
    private bool run_flag = false;
    private uint cnt;
    private int cnt2;
    private uint play_flag = 0;
    private int data_n = 100;
    private int time_n = 5;
    private int speed_value = 1;
    private int fgdata_index = 0;
    private int fgdata_index_max = 0;
    private int start_index = 0;
    private int end_index = 0;
    private string filename;
    private const int length = 0;
    private string fileName = string.Empty;
    private int a_tic = 0;
    private IContainer components = (IContainer) null;
    private Button buttonPlay;
    private Button buttonOpenFile;
    private TextBox textBoxFileName;
    private Label label6;
    private Label label5;
    private Label label4;
    private Label labelNow;
    private Label label8;
    private TrackBar trackBaNow;
    private Label labelEnd;
    private Label label2;
    private ProgressBar progressBarPercent;
    private TrackBar trackBar_speed;

    [DllImport("winmm")]
    private static extern uint timeGetTime();

    [DllImport("winmm")]
    private static extern void timeBeginPeriod(int t);

    [DllImport("winmm")]
    private static extern uint timeEndPeriod(int t);

    public DataReplayWindow()
    {
      this.InitializeComponent();
      this.progressBarPercent.Visible = false;
      this.timer.Interval = 100;
      this.timer.Tick += new EventHandler(this.Timer_Tick);
      this.timer.Start();
      this.timer_play.Interval = 10;
      this.timer_play.Tick += new EventHandler(this.Timer_Play);
      this.timer_play.Start();
    }

    private void DataReplayWindow_Load(object sender, EventArgs e)
    {
    }

    private void Timer_Play(object sender, EventArgs e)
    {
      int num = DateTime.Now.Subtract(this.play_tic).Milliseconds / 100;
      if (this.a_tic == num)
        return;
      this.a_tic = num;
      this.timerfunction();
    }

    private void Timer_Tick(object sender, EventArgs e)
    {
      this.progressBarPercent.Value = this.FileRead.Process;
      if (this.FileRead.Process == 100)
      {
        if (this.file_open_flag != 0U)
          return;
        this.file_open_flag = 1U;
        this.fgdata_index_max = this.FileRead.Data.Count;
        this.end_index = this.fgdata_index_max;
        this.labelEnd.Text = this.sec_to_hms((long) (this.fgdata_index_max / 10));
        this.start_index = 0;
        this.fgdata_index = 0;
        this.progressBarPercent.Visible = false;
        switch (SetParameter.Language)
        {
          case "en-US":
            this.textBoxFileName.Text = "Successfully opened：" + Path.GetFileName(this.filename);
            this.buttonPlay.Text = "Play";
            break;
          case "zh-TW":
            this.textBoxFileName.Text = "成功打開：" + Path.GetFileName(this.filename);
            this.buttonPlay.Text = "播放";
            break;
          default:
            this.textBoxFileName.Text = "成功打开：" + Path.GetFileName(this.filename);
            this.buttonPlay.Text = "播放";
            break;
        }
        this.play_flag = 0U;
        this.trackBaNow.Value = 0;
      }
      else
        this.file_open_flag = 0U;
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
      Common.SerialManager.EnableReceive = true;
      Common.StatusStr = "";
      this.timer.Stop();
      e.Cancel = true;
      this.play_flag = 0U;
      switch (SetParameter.Language)
      {
        case "en-US":
          this.buttonPlay.Text = "Play";
          break;
        case "zh-TW":
          this.buttonPlay.Text = "播放";
          break;
        default:
          this.buttonPlay.Text = "播放";
          break;
      }
      this.Hide();
    }

    private void buttonPlay_Click(object sender, EventArgs e)
    {
      if (this.FileRead.Data != null)
      {
        if (this.play_flag == 1U)
        {
          this.play_flag = 0U;
          switch (SetParameter.Language)
          {
            case "en-US":
              this.buttonPlay.Text = "Play";
              break;
            case "zh-TW":
              this.buttonPlay.Text = "播放";
              break;
            default:
              this.buttonPlay.Text = "播放";
              break;
          }
        }
        else
        {
          this.play_flag = 1U;
          switch (SetParameter.Language)
          {
            case "en-US":
              this.buttonPlay.Text = "Suspend";
              break;
            case "zh-TW":
              this.buttonPlay.Text = "暫停";
              break;
            default:
              this.buttonPlay.Text = "暂停";
              break;
          }
        }
      }
      else
      {
        switch (SetParameter.Language)
        {
          case "en-US":
            int num1 = (int) MessageBox.Show("Please open the data file first");
            break;
          case "zh-TW":
            int num2 = (int) MessageBox.Show("請先打開資料檔案");
            break;
          default:
            int num3 = (int) MessageBox.Show("请先打开数据文件");
            break;
        }
      }
    }

    private void buttonOpenFile_Click(object sender, EventArgs e)
    {
      try
      {
        this.play_flag = 0U;
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filter = "(*.d)|*.d";
        if (openFileDialog.ShowDialog() != DialogResult.OK)
          return;
        this.textBoxFileName.Text = "";
        this.run_flag = false;
        this.timer.Start();
        this.filename = openFileDialog.FileName;
        this.FileRead.Read(openFileDialog.FileName);
        this.progressBarPercent.Visible = true;
      }
      catch
      {
      }
    }

    private void trackBaNow_Scroll(object sender, EventArgs e)
    {
      this.fgdata_index = this.trackBaNow.Value * this.fgdata_index_max / 1000;
      this.labelNow.Text = this.sec_to_hms((long) (this.fgdata_index / 10));
    }

    private string sec_to_hms(long duration)
    {
      TimeSpan timeSpan = new TimeSpan(0, 0, Convert.ToInt32(duration));
      string hms = "";
      if (timeSpan.Hours > 0)
        hms = string.Format("{0:00}", (object) timeSpan.Hours) + ":" + string.Format("{0:00}", (object) timeSpan.Minutes) + ":" + string.Format("{0:00}", (object) timeSpan.Seconds);
      if (timeSpan.Hours == 0 && timeSpan.Minutes > 0)
        hms = "00:" + string.Format("{0:00}", (object) timeSpan.Minutes) + ":" + string.Format("{0:00}", (object) timeSpan.Seconds);
      if (timeSpan.Hours == 0 && timeSpan.Minutes == 0)
        hms = "00:00:" + string.Format("{0:00}", (object) timeSpan.Seconds);
      return hms;
    }

    private void timerfunction()
    {
      if (this.play_flag != 1U)
        return;
      this.get_send_data(this.fgdata_index);
      this.Invoke((Delegate) (data1 =>
      {
        this.labelNow.Text = this.sec_to_hms((long) (data1 / 10));
        this.trackBaNow.Value = data1 * 1000 / this.fgdata_index_max;
      }), (object) this.fgdata_index);
      this.fgdata_index += this.speed_value;
      if (this.fgdata_index > this.fgdata_index_max)
      {
        this.fgdata_index = this.fgdata_index_max;
        this.play_flag = 0U;
      }
    }

    private double FindData(int index, string name)
    {
      double data = 0.0;
      int index1 = this.FileRead.Titles.ToList<string>().IndexOf(name);
      if (index1 >= 0 && index < this.FileRead.Data.Count)
        data = this.FileRead.Data[index][index1];
      return data;
    }

    private void get_send_data(int index)
    {
      Common.StatusStr = "记录回放";
      Common.SerialManager.EnableReceive = false;
      C2_Content_Common.Data.mode = (byte) this.FindData(index, "eng_cfg.mode");
      byte[] numArray = new byte[8]
      {
        (byte) this.FindData(index, "eng_0.cdi_enable"),
        (byte) this.FindData(index, "eng_1.cdi_enable"),
        (byte) this.FindData(index, "eng_dat.pump_enable"),
        (byte) this.FindData(index, "eng_0.oil_enable"),
        (byte) this.FindData(index, "bus.fly"),
        (byte) this.FindData(index, "sys.ver"),
        (byte) this.FindData(index, "eng_dat.jet_test"),
        (byte) this.FindData(index, "eng_0.ext_two_flg")
      };
      C2_Content_Common.Data.sta = (byte) ((int) (byte) ((uint) numArray[0] & 1U) | (int) (byte) ((uint) numArray[1] & 1U) << 1 | (int) (byte) ((uint) numArray[2] & 1U) << 2 | (int) (byte) ((uint) numArray[3] & 1U) << 3 | (int) (byte) ((uint) numArray[4] & 1U) << 4 | (int) (byte) ((uint) numArray[5] & 1U) << 5 | (int) (byte) ((uint) numArray[6] & 1U) << 6 | (int) (byte) ((uint) numArray[7] & 1U) << 7);
      C2_Content_Common.Data.bus_thr = (byte) (this.FindData(index, "bus.thr_in") / 10.0);
      C2_Content_Common.Data.svr_pwm = (byte) (this.FindData(index, "bus.thr_exp") / 10.0);
      C2_Content_Common.Data.rpm_out = (ushort) this.FindData(index, "eng_dat.rpm_show");
      C2_Content_Common.Data.rpm1 = (ushort) this.FindData(index, "eng_0.rpm_val");
      C2_Content_Common.Data.rpm2 = (ushort) this.FindData(index, "eng_1.rpm_val");
      C2_Content_Common.Data.tmp_env = (short) this.FindData(index, "ms.correct_tmp");
      C2_Content_Common.Data.tmp0 = (short) this.FindData(index, "eng_dat.temp1");
      C2_Content_Common.Data.tmp1 = (short) this.FindData(index, "eng_dat.temp2");
      C2_Content_Common.Data.tmp2 = (short) this.FindData(index, "eng_dat.temp3");
      C2_Content_Common.Data.tmp3 = (short) this.FindData(index, "eng_dat.temp4");
      C2_Content_Common.Data.vol_power = (ushort) (this.FindData(index, "adc.vol_power_lpf") * 10.0);
      C2_Content_Common.Data.vol_svr = (byte) (this.FindData(index, "adc.vol_svr") * 10.0);
      C2_Content_Common.Data.vol_pump = (byte) (this.FindData(index, "adc.vol_out") * 10.0);
      C2_Content_Common.Data.amp_pump = (byte) (this.FindData(index, "adc.amp_pump_lpf") * 10.0);
      C2_Content_Common.Data.madc1 = (byte) (this.FindData(index, "adc.vol_adc1") * 10.0);
      C2_Content_Common.Data.madc2 = (byte) (this.FindData(index, "adc.vol_adc2") * 10.0);
      C2_Content_Common.Data.pre_gas = (float) this.FindData(index, "ms.pre");
      C2_Content_Common.Data.pre_alt = (short) this.FindData(index, "ms.alt_lpf");
      C2_Content_Common.Data.PWM_IN1 = (byte) (this.FindData(index, "bus.pwm_in1_per") / 10.0);
      C2_Content_Common.Data.PWM_IN2 = (byte) (this.FindData(index, "bus.pwm_in2_per") / 10.0);
      C2_Content_Common.Data.PWM_IN3 = (byte) (this.FindData(index, "bus.pwm_in3_per") / 10.0);
      C2_Content_Common.Data.PWM_OUT1 = (byte) this.FileRead.Data[index][this.FileRead.Titles.ToList<string>().IndexOf("bus.thr_out_pwm1")];
      C2_Content_Common.Data.PWM_OUT2 = (byte) this.FileRead.Data[index][this.FileRead.Titles.ToList<string>().IndexOf("bus.thr_out_pwm2")];
      C2_Content_Common.Data.PWM_OUT3 = (byte) this.FileRead.Data[index][this.FileRead.Titles.ToList<string>().IndexOf("bus.thr_out_pwm3")];
      C2_Content_Common.Data.pre_oil = (float) this.FindData(index, "adc.vol_adc3");
      C2_Content_Common.Data.inj1_ms = (ushort) (this.FindData(index, "eng_0.oil_ms_show") * 100.0);
      C2_Content_Common.Data.inj2_ms = (ushort) (this.FindData(index, "eng_1.oil_ms_show") * 100.0);
      C2_Content_Common.Data.inj1_mg = (ushort) (this.FindData(index, "eng_0.oil_mg_total") * 100.0);
      C2_Content_Common.Data.inj2_mg = (ushort) (this.FindData(index, "eng_1.oil_mg_total") * 100.0);
      C2_Content_Common.Data.eng_run_time = (uint) (ushort) this.FindData(index, "eng_dat.pcb_run_sec");
      C2_Content_Common.Data.err_flg = (ushort) this.FindData(index, "chk.flg0_chk_err");
    }

    private void trackBar_speed_Scroll(object sender, EventArgs e)
    {
      switch (this.trackBar_speed.Value)
      {
        case 1:
          this.speed_value = 1;
          break;
        case 2:
          this.speed_value = 5;
          break;
        case 3:
          this.speed_value = 10;
          break;
        case 4:
          this.speed_value = 20;
          break;
        case 5:
          this.speed_value = 30;
          break;
        case 6:
          this.speed_value = 40;
          break;
        case 7:
          this.speed_value = 50;
          break;
        case 8:
          this.speed_value = 60;
          break;
      }
      this.label5.Text = this.speed_value.ToString("f2");
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (DataReplayWindow));
      this.buttonPlay = new Button();
      this.buttonOpenFile = new Button();
      this.textBoxFileName = new TextBox();
      this.label6 = new Label();
      this.label5 = new Label();
      this.label4 = new Label();
      this.labelNow = new Label();
      this.label8 = new Label();
      this.trackBaNow = new TrackBar();
      this.labelEnd = new Label();
      this.label2 = new Label();
      this.progressBarPercent = new ProgressBar();
      this.trackBar_speed = new TrackBar();
      this.trackBaNow.BeginInit();
      this.trackBar_speed.BeginInit();
      this.SuspendLayout();
      componentResourceManager.ApplyResources((object) this.buttonPlay, "buttonPlay");
      this.buttonPlay.Name = "buttonPlay";
      this.buttonPlay.UseVisualStyleBackColor = true;
      this.buttonPlay.Click += new EventHandler(this.buttonPlay_Click);
      componentResourceManager.ApplyResources((object) this.buttonOpenFile, "buttonOpenFile");
      this.buttonOpenFile.Name = "buttonOpenFile";
      this.buttonOpenFile.UseVisualStyleBackColor = true;
      this.buttonOpenFile.Click += new EventHandler(this.buttonOpenFile_Click);
      componentResourceManager.ApplyResources((object) this.textBoxFileName, "textBoxFileName");
      this.textBoxFileName.Name = "textBoxFileName";
      this.textBoxFileName.ReadOnly = true;
      componentResourceManager.ApplyResources((object) this.label6, "label6");
      this.label6.Name = "label6";
      componentResourceManager.ApplyResources((object) this.label5, "label5");
      this.label5.Name = "label5";
      componentResourceManager.ApplyResources((object) this.label4, "label4");
      this.label4.Name = "label4";
      componentResourceManager.ApplyResources((object) this.labelNow, "labelNow");
      this.labelNow.Name = "labelNow";
      componentResourceManager.ApplyResources((object) this.label8, "label8");
      this.label8.Name = "label8";
      componentResourceManager.ApplyResources((object) this.trackBaNow, "trackBaNow");
      this.trackBaNow.Maximum = 1000;
      this.trackBaNow.Name = "trackBaNow";
      this.trackBaNow.Scroll += new EventHandler(this.trackBaNow_Scroll);
      componentResourceManager.ApplyResources((object) this.labelEnd, "labelEnd");
      this.labelEnd.Name = "labelEnd";
      componentResourceManager.ApplyResources((object) this.label2, "label2");
      this.label2.Name = "label2";
      componentResourceManager.ApplyResources((object) this.progressBarPercent, "progressBarPercent");
      this.progressBarPercent.Name = "progressBarPercent";
      componentResourceManager.ApplyResources((object) this.trackBar_speed, "trackBar_speed");
      this.trackBar_speed.Maximum = 8;
      this.trackBar_speed.Minimum = 1;
      this.trackBar_speed.Name = "trackBar_speed";
      this.trackBar_speed.Value = 1;
      this.trackBar_speed.Scroll += new EventHandler(this.trackBar_speed_Scroll);
      componentResourceManager.ApplyResources((object) this, "$this");
      this.AutoScaleMode = AutoScaleMode.Font;
      this.Controls.Add((Control) this.trackBar_speed);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.progressBarPercent);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.labelNow);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.label8);
      this.Controls.Add((Control) this.trackBaNow);
      this.Controls.Add((Control) this.labelEnd);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.buttonPlay);
      this.Controls.Add((Control) this.buttonOpenFile);
      this.Controls.Add((Control) this.textBoxFileName);
      this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (DataReplayWindow);
      this.Opacity = 0.8;
      this.TopMost = true;
      this.Load += new EventHandler(this.DataReplayWindow_Load);
      this.trackBaNow.EndInit();
      this.trackBar_speed.EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
