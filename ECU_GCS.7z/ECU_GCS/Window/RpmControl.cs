﻿// Decompiled with JetBrains decompiler
// Type: ECU_GCS.Window.RpmControl
// Assembly: ECU_GCS, Version=1.0.2.2, Culture=neutral, PublicKeyToken=null
// MVID: 4AB9C9F1-17D5-4990-AB25-69949DD24666
// Assembly location: D:\Business\OneDrive\Spatial_Collect\2.Agencies\1.Innoflight\10.Software\EFI SW V1.0\ECU_GCS.exe

using ECU_GCS.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Timers;
using System.Windows.Forms;

namespace ECU_GCS.Window
{
  public class RpmControl : UserControl
  {
    private float minValue = 0.0f;
    private float maxValue = 100f;
    private float changeValue = 0.0f;
    private Color pinColor = Color.FromArgb(191, 148, 28);
    private Color markColor = Color.FromArgb(250, 250, 250);
    private string unitText = "W";
    private string _midText = "RPM";
    private int minunit = 1;
    private int autoDiameter = 200;
    private float multiple = 1f;
    private int intervalValue;
    private float diameter;
    private float value;
    private const int Speed = 10;
    private int speedtime = 10;
    private Image dashboardImage;
    private System.Timers.Timer SystemTimer = new System.Timers.Timer();
    private IContainer components = (IContainer) null;
    private System.Windows.Forms.Timer timer1;

    [Category("自定义属性")]
    [Description("仪表盘显示的最小值")]
    public float MinValue
    {
      get => this.minValue;
      set
      {
        if ((double) value >= (double) this.MaxValue)
        {
          int num = (int) MessageBox.Show("最小值不能超过最大值！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        else
          this.minValue = value;
      }
    }

    [Category("自定义属性")]
    [Description("仪表盘上显示的最大值")]
    public float MaxValue
    {
      get => this.maxValue;
      set
      {
        if ((double) value <= (double) this.MinValue)
        {
          int num = (int) MessageBox.Show("最大值不能低于最小值！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        else
          this.maxValue = value;
      }
    }

    [Category("自定义属性")]
    [Description("仪表盘上变化的值")]
    public float ChangeValue
    {
      get => this.changeValue;
      set => this.changeValue = value;
    }

    [Category("自定义属性")]
    [Description("仪表盘上指针的颜色")]
    public Color PinColor
    {
      get => this.pinColor;
      set => this.pinColor = value;
    }

    [Category("自定义属性")]
    [Description("仪表盘上刻度字的颜色")]
    public Color MarkColor
    {
      get => this.markColor;
      set => this.markColor = value;
    }

    [Category("自定义属性")]
    [Description("单位关联文本")]
    public string UnitText
    {
      get => this.unitText;
      set => this.unitText = value;
    }

    [Category("自定义属性")]
    [Description("标题")]
    [DefaultValue("RPM")]
    public string MidText
    {
      get => this._midText;
      set => this._midText = value;
    }

    [Category("自定义属性")]
    [Description("单位关联文本,默认1")]
    public int MinUnit
    {
      get => this.minunit;
      set => this.minunit = value;
    }

    public RpmControl()
    {
      this.InitializeComponent();
      this.SetStyle(ControlStyles.UserPaint, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer, true);
      this.UpdateStyles();
      this.dashboardImage = (Image) Resources.Ellipse;
      this.InitialCanvas();
    }

    public void InitialCanvas()
    {
      this.diameter = this.Width <= this.Height ? (float) (this.Width - 6) : (float) (this.Height - 6);
      if ((double) this.diameter < 1.0)
        return;
      this.multiple = this.diameter / (float) this.autoDiameter;
      this.intervalValue = (int) (((double) this.MaxValue - (double) this.minValue) / 4.0 / (double) this.MinUnit);
      this.drawBackImage();
    }

    public void drawBackImage()
    {
      if ((double) this.multiple == 0.0 || this.dashboardImage == null)
        return;
      Bitmap bitmap = new Bitmap(this.Width, this.Height);
      Graphics graphics = Graphics.FromImage((Image) bitmap);
      graphics.SmoothingMode = SmoothingMode.HighQuality;
      float dx = (float) (this.Width / 2);
      float dy = (float) (this.Height / 2);
      float num1 = this.diameter / 2f;
      graphics.TranslateTransform(dx, dy);
      graphics.DrawImage(this.dashboardImage, -num1, -num1, this.diameter, this.diameter);
      Font font1 = new Font("微软雅黑", 50f * this.multiple, FontStyle.Bold);
      SizeF sizeF1 = graphics.MeasureString(this.MidText, font1);
      Color color = Color.FromArgb(42, 57, 89);
      graphics.DrawString(this.MidText, font1, (Brush) new SolidBrush(color), (float) (-(double) sizeF1.Width / 2.0), (float) (-(double) sizeF1.Height / 2.0));
      Font font2 = new Font("宋体", 9f * this.multiple, FontStyle.Bold);
      float num2 = 270f;
      float num3 = 0.0f;
      Color markColor = this.MarkColor;
      float num4 = num1 - 30f * this.multiple;
      for (int index = 0; index < 5; ++index)
      {
        int num5 = index * this.intervalValue;
        SizeF sizeF2 = graphics.MeasureString(num5.ToString(), font2);
        double num6 = ((double) num3 + (double) num2) * Math.PI / 180.0;
        float num7 = num4 * (float) Math.Cos(num6);
        float num8 = num4 * (float) Math.Sin(num6);
        if ((double) num3 == 0.0)
          graphics.DrawString(num5.ToString(), font2, Brushes.Wheat, num7 - sizeF2.Width / 2f, num8 - sizeF2.Height / 2f);
        else if ((double) num3 == 30.0)
          graphics.DrawString(num5.ToString(), font2, (Brush) new SolidBrush(markColor), num7 - sizeF2.Width / 2f, num8 - sizeF2.Height / 2f);
        else if ((double) num3 == 60.0)
          graphics.DrawString(num5.ToString(), font2, (Brush) new SolidBrush(markColor), (float) ((double) num7 - (double) sizeF2.Width + 8.0 * (double) this.multiple), (float) ((double) num8 - (double) sizeF2.Height / 2.0 + 5.0 * (double) this.multiple));
        else if ((double) num3 == 90.0)
          graphics.DrawString(num5.ToString(), font2, (Brush) new SolidBrush(markColor), (float) ((double) num7 - (double) sizeF2.Width + 8.0 * (double) this.multiple), num8 - sizeF2.Height / 2f);
        else if ((double) num3 == 120.0)
          graphics.DrawString(num5.ToString(), font2, (Brush) new SolidBrush(markColor), (float) ((double) num7 - (double) sizeF2.Width + 8.0 * (double) this.multiple), num8 - sizeF2.Height / 2f);
        num3 += 30f;
      }
      float num9 = 270f;
      float num10 = 0.0f;
      for (int index = 0; index < 5; ++index)
      {
        int num11 = -index * this.intervalValue;
        SizeF sizeF3 = graphics.MeasureString(num11.ToString(), font2);
        double num12 = ((double) num10 + (double) num9) * Math.PI / 180.0;
        float num13 = num4 * (float) Math.Cos(num12);
        float num14 = num4 * (float) Math.Sin(num12);
        if ((double) num10 == -30.0)
          graphics.DrawString(num11.ToString(), font2, Brushes.Red, num13 - sizeF3.Width / 2f, num14 - sizeF3.Height / 2f);
        else if ((double) num10 == -60.0)
          graphics.DrawString(num11.ToString(), font2, Brushes.Red, num13 - 8f * this.multiple, (float) ((double) num14 - (double) sizeF3.Height / 2.0 + 5.0 * (double) this.multiple));
        else if ((double) num10 == -90.0)
          graphics.DrawString(num11.ToString(), font2, Brushes.Red, num13 - 8f * this.multiple, num14 - sizeF3.Height / 2f);
        else if ((double) num10 == -120.0)
          graphics.DrawString(num11.ToString(), font2, Brushes.Red, num13 - 8f * this.multiple, num14 - sizeF3.Height / 2f);
        num10 -= 30f;
      }
      graphics.Dispose();
      this.BackgroundImage = (Image) bitmap;
    }

    private void Drawing(Graphics g)
    {
      if ((double) this.multiple == 0.0)
        return;
      Bitmap bitmap = new Bitmap(this.Width, this.Height);
      Graphics graphics = Graphics.FromImage((Image) bitmap);
      graphics.SmoothingMode = SmoothingMode.HighQuality;
      float dx = (float) (this.Width / 2);
      float dy = (float) (this.Height / 2);
      float num1 = this.diameter / 2f;
      graphics.TranslateTransform(dx, dy);
      float angle = (float) ((double) this.value / (double) this.MaxValue * 120.0);
      float num2 = this.value / (float) this.MinUnit;
      Font font = new Font("微软雅黑", 13f * this.multiple, FontStyle.Bold);
      string str = this.MinUnit < 1000 ? num2.ToString("f1") + this.UnitText : num2.ToString("f1") + "k" + this.UnitText;
      SizeF sizeF = graphics.MeasureString(str, font);
      graphics.DrawString(str, font, (Brush) new SolidBrush(Color.FromArgb(216, 224, 241)), (float) (-(double) sizeF.Width / 2.0), 30f * this.multiple);
      graphics.FillEllipse((Brush) new SolidBrush(this.PinColor), -5, -5, 10, 10);
      graphics.RotateTransform(angle);
      graphics.DrawLine(new Pen(this.PinColor, 3f), 0.0f, 20f * this.multiple, 0.0f, (float) (-(double) num1 + 15.0 * (double) this.multiple));
      graphics.Dispose();
      g.DrawImage((Image) bitmap, 0, 0);
    }

    private void MetalDashboardUserCtrl_Load(object sender, EventArgs e)
    {
      this.timer1.Interval = 1;
      this.timer1.Start();
    }

    private void MetalDashboardUserCtrl_Paint(object sender, PaintEventArgs e) => this.Drawing(e.Graphics);

    private void MetalDashboardUserCtrl_Resize(object sender, EventArgs e)
    {
      this.InitialCanvas();
      this.Refresh();
    }

    private void SystemTimer_Elapsed(object sender, ElapsedEventArgs e)
    {
      if ((double) this.ChangeValue > (double) this.value)
      {
        float num = (this.ChangeValue - this.value) / (float) this.speedtime;
        if (this.speedtime > 0)
        {
          --this.speedtime;
          this.value += num;
        }
        if (this.speedtime == 0)
          this.speedtime = 10;
        this.Invoke((Delegate) (() => this.Refresh()));
      }
      else
      {
        if ((double) this.ChangeValue >= (double) this.value)
          return;
        float num = (this.value - this.ChangeValue) / (float) this.speedtime;
        if (this.speedtime > 0)
        {
          --this.speedtime;
          this.value -= num;
        }
        if (this.speedtime == 0)
          this.speedtime = 10;
        this.Invoke((Delegate) (() => this.Refresh()));
      }
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      if ((double) this.ChangeValue > (double) this.value)
      {
        float num = (this.ChangeValue - this.value) / (float) this.speedtime;
        if (this.speedtime > 0)
        {
          --this.speedtime;
          this.value += num;
        }
        if (this.speedtime == 0)
          this.speedtime = 10;
        this.Refresh();
      }
      else
      {
        if ((double) this.ChangeValue >= (double) this.value)
          return;
        float num = (this.value - this.ChangeValue) / (float) this.speedtime;
        if (this.speedtime > 0)
        {
          --this.speedtime;
          this.value -= num;
        }
        if (this.speedtime == 0)
          this.speedtime = 10;
        this.Refresh();
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new System.ComponentModel.Container();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      this.timer1.Interval = 1;
      this.timer1.Tick += new EventHandler(this.timer1_Tick);
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.MinimumSize = new Size(100, 100);
      this.Name = nameof (RpmControl);
      this.Size = new Size(200, 200);
      this.Load += new EventHandler(this.MetalDashboardUserCtrl_Load);
      this.Paint += new PaintEventHandler(this.MetalDashboardUserCtrl_Paint);
      this.Resize += new EventHandler(this.MetalDashboardUserCtrl_Resize);
      this.ResumeLayout(false);
    }
  }
}
